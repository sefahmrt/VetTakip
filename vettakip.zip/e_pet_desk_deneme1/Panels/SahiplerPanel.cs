﻿using System;
using System.Windows.Forms;
using Microsoft.Data.Sqlite; // Güncel kütüphane

namespace e_pet_desk_deneme1
{
    public partial class SahiplerPanel : UserControl
    {
        public SahiplerPanel()
        {
            InitializeComponent();
            MusterileriListele();
        }

        private void MusterileriListele()
        {
            flowPanelSahipler.Controls.Clear();

            // Takvim ile aynı veritabanı bağlantısı
            string connectionString = "Data Source=demo.db;Foreign Keys=True";

            using (SqliteConnection conn = new SqliteConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    // tel_no yerine tel yazıldı ve sadece aktif müşteriler çekiliyor
                    string query = "SELECT ad, soyad, tel, adres FROM musteri WHERE aktif = 1";

                    using (SqliteCommand cmd = new SqliteCommand(query, conn))
                    {
                        using (SqliteDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                MusteriKartiUserControl kart = new MusteriKartiUserControl();

                                kart.AdSoyad = reader["ad"].ToString() + " " + reader["soyad"].ToString();
                                kart.Telefon = reader["tel"].ToString(); // Sütun adı düzeltildi
                                kart.Adres = reader["adres"].ToString();

                                flowPanelSahipler.Controls.Add(kart);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Bir hata oluştu: " + ex.Message);
                }
            }
        }
    }
}